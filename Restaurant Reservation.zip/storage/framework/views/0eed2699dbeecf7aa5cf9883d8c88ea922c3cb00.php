<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\Project_Final\Restaurant Reservation\laravel-restaurant-reservation\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>