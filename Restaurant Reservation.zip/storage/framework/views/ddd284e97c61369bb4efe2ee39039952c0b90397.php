<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === 'Laravel'): ?>
<img src="https://www.upload.ee/image/14245863/logo4.png" class="logo" alt="Sandra Kuliner Logo">
<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH C:\laragon\www\Project_Final\Restaurant Reservation\laravel-restaurant-reservation\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>